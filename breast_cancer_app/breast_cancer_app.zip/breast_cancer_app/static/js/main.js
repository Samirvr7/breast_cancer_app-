(function () {
  const form = document.getElementById('patient-form');
  const segButtons = document.querySelectorAll('.seg');
  const modelInput = document.getElementById('model-input');
  const submitBtn = document.getElementById('submit-btn');

  const resultEmpty = document.getElementById('result-empty');
  const resultFilled = document.getElementById('result-filled');
  const gaugeFill = document.getElementById('gauge-fill');
  const gaugeNeedle = document.getElementById('gauge-needle');
  const gaugeValue = document.getElementById('gauge-value');
  const riskBadge = document.getElementById('risk-badge');
  const modelLabel = document.getElementById('result-model-label');
  const factorList = document.getElementById('factor-list');

  const GAUGE_CIRCUMFERENCE = 251.2; // matches stroke-dasharray in CSS

  segButtons.forEach((btn) => {
    btn.addEventListener('click', () => {
      segButtons.forEach((b) => b.classList.remove('active'));
      btn.classList.add('active');
      modelInput.value = btn.dataset.model;
    });
  });

  function riskLabel(tier) {
    return { low: 'Low risk', moderate: 'Moderate risk', high: 'High risk' }[tier] || tier;
  }

  function renderFactors(modelKey) {
    factorList.innerHTML = '';
    const data = window.__IMPORTANCES__;
    if (!data) return;
    const list = data[modelKey] || [];
    list.slice(0, 6).forEach((item) => {
      const li = document.createElement('li');
      const name = document.createElement('span');
      name.textContent = item.feature.replace(/_/g, ' ');
      const val = document.createElement('span');
      val.className = 'f-val';
      val.textContent = item.value.toFixed(3);
      li.appendChild(name);
      li.appendChild(val);
      factorList.appendChild(li);
    });
  }

  form.addEventListener('submit', async (e) => {
    e.preventDefault();
    submitBtn.disabled = true;
    submitBtn.textContent = 'Scoring…';

    const payload = { model: modelInput.value };
    new FormData(form).forEach((value, key) => { payload[key] = value; });

    try {
      const res = await fetch('/api/predict', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify(payload),
      });
      const data = await res.json();
      if (!res.ok) throw new Error(data.error || 'Prediction failed');

      resultEmpty.hidden = true;
      resultFilled.hidden = false;

      const pct = Math.round(data.probability_malignant * 100);
      gaugeValue.textContent = pct + '%';

      const offset = GAUGE_CIRCUMFERENCE * (1 - data.probability_malignant);
      gaugeFill.style.strokeDashoffset = offset;

      const angle = -90 + (180 * data.probability_malignant);
      gaugeNeedle.style.transform = `rotate(${angle}deg)`;

      const colorMap = { low: '#2C7A56', moderate: '#C97E2B', high: '#B3392C' };
      gaugeFill.style.stroke = colorMap[data.risk_tier] || '#0E7C86';

      riskBadge.textContent = `${riskLabel(data.risk_tier)} · ${data.prediction}`;
      riskBadge.className = 'risk-badge ' + data.risk_tier;

      modelLabel.textContent = `Scored with ${data.model_used}`;

      renderFactors(modelInput.value);
    } catch (err) {
      alert(err.message);
    } finally {
      submitBtn.disabled = false;
      submitBtn.textContent = 'Run assessment';
    }
  });
})();
